export * from './home-aux.component';
