import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-aux',
  templateUrl: './home-aux.component.html',
  styleUrls: ['./home-aux.component.css']
})
export class HomeAuxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
