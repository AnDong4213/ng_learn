export const environment = {
  production: true,
  baseUrl: 'http://apis.imooc.com/api',
  icode: 'xxxxx'
};
