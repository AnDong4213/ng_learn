export * from './child.component';
