export * from './parent.component';
